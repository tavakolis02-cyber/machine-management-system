# Machine & Equipment Management System (Sample Project)

This is a sample combined project for a Machine & Equipment Management System.
It includes a Django backend (API) and a PyQt desktop client (operator).

## Quickstart (local)

### Backend
```bash
cd backend
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows
pip install -r requirements.txt
# create Django project structure if needed, migrate and create superuser
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

### Desktop
```bash
cd desktop
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python run_app.py
```

## What's included
- backend/machines: models, serializers, views
- backend/backend/urls.py: API routes
- desktop/run_app.py: simple PyQt client that authenticates and lists machines

## Notes
This is a starter sample to use as portfolio. For production readiness additional work (Docker, PostgreSQL, security, translations, better UI) is required.
