import sys
import requests
from PyQt6 import QtWidgets, QtCore

API_BASE = 'http://127.0.0.1:8000/api/'

class LoginWindow(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Login - Machine Manager')
        self.resize(400,200)
        layout = QtWidgets.QVBoxLayout()
        self.email = QtWidgets.QLineEdit()
        self.email.setPlaceholderText('username')
        self.password = QtWidgets.QLineEdit()
        self.password.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password)
        self.password.setPlaceholderText('password')
        self.btn = QtWidgets.QPushButton('Login')
        self.btn.clicked.connect(self.do_login)
        layout.addWidget(self.email)
        layout.addWidget(self.password)
        layout.addWidget(self.btn)
        self.setLayout(layout)

    def do_login(self):
        data = {'username': self.email.text(), 'password': self.password.text()}
        try:
            r = requests.post(API_BASE + 'token/', json=data)
            if r.status_code == 200:
                token = r.json().get('access')
                self.main = MainWindow(token)
                self.main.show()
                self.close()
            else:
                QtWidgets.QMessageBox.warning(self, 'Error', 'Login failed')
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, 'Error', str(e))

class MainWindow(QtWidgets.QWidget):
    def __init__(self, token):
        super().__init__()
        self.token = token
        self.setWindowTitle('Machine Manager - Operator')
        self.resize(800,600)
        layout = QtWidgets.QHBoxLayout()
        self.list_widget = QtWidgets.QListWidget()
        self.detail = QtWidgets.QTextEdit()
        layout.addWidget(self.list_widget, 30)
        layout.addWidget(self.detail, 70)
        self.setLayout(layout)
        self.load_machines()

    def load_machines(self):
        headers = {'Authorization': f'Bearer {self.token}'}
        r = requests.get(API_BASE + 'machines/', headers=headers)
        if r.status_code == 200:
            for m in r.json():
                item = QtWidgets.QListWidgetItem(f"{m['name']} - {m['status']}")
                item.setData(QtCore.Qt.ItemDataRole.UserRole, m)
                self.list_widget.addItem(item)
            self.list_widget.itemClicked.connect(self.show_detail)
        else:
            QtWidgets.QMessageBox.warning(self, 'Error', 'Could not load machines')

    def show_detail(self, item):
        m = item.data(QtCore.Qt.ItemDataRole.UserRole)
        text = f"Name: {m['name']}\nModel: {m['model']}\nStatus: {m['status']}\nLocation: {m['location']}\n"
        self.detail.setPlainText(text)

if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    w = LoginWindow()
    w.show()
    sys.exit(app.exec())
