Machine & Equipment Management System — One Pager

Purpose: Manage machines, parts and service records via a web admin and a desktop operator client.

Tech stack:
- Backend: Django + DRF
- Desktop: PyQt6
- Reporting: pandas, ReportLab / Excel export

Key features:
- CRUD for machines, parts and services
- Dashboard with KPIs (planned)
- Export to Excel/PDF
- Two-language support (EN / FA)
