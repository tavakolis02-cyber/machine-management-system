from rest_framework import viewsets, permissions
from .models import Machine, Part, ServiceRecord
from .serializers import MachineSerializer, PartSerializer, ServiceRecordSerializer

class MachineViewSet(viewsets.ModelViewSet):
    queryset = Machine.objects.all().order_by('name')
    serializer_class = MachineSerializer
    permission_classes = [permissions.IsAuthenticated]

class PartViewSet(viewsets.ModelViewSet):
    queryset = Part.objects.all()
    serializer_class = PartSerializer
    permission_classes = [permissions.IsAuthenticated]

class ServiceRecordViewSet(viewsets.ModelViewSet):
    queryset = ServiceRecord.objects.all().order_by('-service_date')
    serializer_class = ServiceRecordSerializer
    permission_classes = [permissions.IsAuthenticated]
