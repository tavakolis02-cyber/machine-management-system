from rest_framework import serializers
from .models import Machine, Part, ServiceRecord

class PartSerializer(serializers.ModelSerializer):
    class Meta:
        model = Part
        fields = '__all__'

class ServiceRecordSerializer(serializers.ModelSerializer):
    parts_used = PartSerializer(many=True, read_only=True)
    class Meta:
        model = ServiceRecord
        fields = '__all__'

class MachineSerializer(serializers.ModelSerializer):
    services = ServiceRecordSerializer(many=True, read_only=True)
    class Meta:
        model = Machine
        fields = '__all__'
