from django.db import models
import uuid

class Machine(models.Model):
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('idle', 'Idle'),
        ('maintenance', 'Maintenance'),
        ('decommissioned', 'Decommissioned'),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=200)
    model = models.CharField(max_length=200, blank=True)
    serial_number = models.CharField(max_length=200, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='active')
    location = models.CharField(max_length=200, blank=True)
    purchase_date = models.DateField(null=True, blank=True)
    next_service_date = models.DateField(null=True, blank=True)

    def __str__(self):
        return f"{self.name} ({self.model})"

class Part(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=200)
    part_number = models.CharField(max_length=200, blank=True)
    quantity_in_stock = models.IntegerField(default=0)
    machine = models.ForeignKey(Machine, null=True, blank=True, on_delete=models.SET_NULL)

    def __str__(self):
        return self.name

class ServiceRecord(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    machine = models.ForeignKey(Machine, on_delete=models.CASCADE, related_name='services')
    parts_used = models.ManyToManyField(Part, blank=True)
    service_type = models.CharField(max_length=200)
    service_date = models.DateTimeField(auto_now_add=True)
    performed_by = models.CharField(max_length=200, blank=True)
    cost = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    notes = models.TextField(blank=True)

    def __str__(self):
        return f"Service on {self.machine.name} @ {self.service_date.date()}"
